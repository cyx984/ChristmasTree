import React, { useState, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState, DualPosition } from '../types';

interface OrnamentsProps {
  count: number;
  treeState: TreeState;
}

const tempObject = new THREE.Object3D();

const Ornaments: React.FC<OrnamentsProps> = React.memo(({ count, treeState }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const [data] = useState<DualPosition[]>(() => {
    const items: DualPosition[] = [];
    for (let i = 0; i < count; i++) {
      const r = 20 * Math.cbrt(Math.random());
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      const chaosPos = new THREE.Vector3(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      const h = Math.random() * 16 - 6; 
      const maxRadius = 7 * (1 - (h + 6) / 20); 
      const radius = Math.random() * maxRadius * 0.9; 
      const angle = Math.random() * Math.PI * 2;
      const targetPos = new THREE.Vector3(
         radius * Math.cos(angle),
         h,
         radius * Math.sin(angle)
      );

      items.push({
        id: i,
        chaosPos,
        targetPos,
        currentPos: chaosPos.clone(),
        rotation: new THREE.Euler(Math.random() * Math.PI, Math.random() * Math.PI, 0),
        scale: Math.random() * 0.3 + 0.1,
        color: Math.random() > 0.6 ? new THREE.Color('#FFD700') : (Math.random() > 0.5 ? new THREE.Color('#8B0000') : new THREE.Color('#C0C0C0'))
      });
    }
    return items;
  });

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    const isFormed = treeState === TreeState.FORMED;
    data.forEach((item, i) => {
      const target = isFormed ? item.targetPos : item.chaosPos;
      const speed = isFormed ? 2.0 + (i % 3) : 1.0; 
      item.currentPos.lerp(target, delta * speed);

      tempObject.position.copy(item.currentPos);
      tempObject.rotation.x = item.rotation.x + state.clock.getElapsedTime() * 0.2;
      tempObject.rotation.y = item.rotation.y + state.clock.getElapsedTime() * 0.5;
      tempObject.scale.setScalar(item.scale);
      
      tempObject.updateMatrix();
      meshRef.current!.setMatrixAt(i, tempObject.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  useLayoutEffect(() => {
    if(meshRef.current) {
        data.forEach((item, i) => {
            if(item.color) meshRef.current!.setColorAt(i, item.color);
        });
        meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [data]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 32, 32]} />
      <meshStandardMaterial 
        roughness={0.1} 
        metalness={0.9} 
        emissive="#331100"
        emissiveIntensity={0.2}
      />
    </instancedMesh>
  );
});

export default Ornaments;