import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';

interface FoliageProps {
  count: number;
  treeState: TreeState;
}

const Foliage: React.FC<FoliageProps> = React.memo(({ count, treeState }) => {
  const mesh = useRef<THREE.Points>(null);
  
  const uniforms = useMemo(() => ({
    uTime: { value: 0 },
    uProgress: { value: 0 }, 
    uColor1: { value: new THREE.Color('#064e3b') }, 
    uColor2: { value: new THREE.Color('#fbbf24') }, 
  }), []);

  const [positions, targetPositions, chaosPositions] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const target = new Float32Array(count * 3);
    const chaos = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const r = 25 * Math.cbrt(Math.random());
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      
      const cx = r * Math.sin(phi) * Math.cos(theta);
      const cy = r * Math.sin(phi) * Math.sin(theta);
      const cz = r * Math.cos(phi);

      chaos[i * 3] = cx;
      chaos[i * 3 + 1] = cy;
      chaos[i * 3 + 2] = cz;

      const h = Math.random() * 18 - 6; 
      const maxRadius = 8 * (1 - (h + 6) / 20); 
      const radius = Math.random() * maxRadius;
      const angle = Math.random() * Math.PI * 2;

      target[i * 3] = radius * Math.cos(angle);
      target[i * 3 + 1] = h;
      target[i * 3 + 2] = radius * Math.sin(angle);

      pos[i * 3] = target[i * 3];
      pos[i * 3 + 1] = target[i * 3 + 1];
      pos[i * 3 + 2] = target[i * 3 + 2];
    }
    return [pos, target, chaos];
  }, [count]);

  useFrame((state) => {
    if (!mesh.current) return;
    const { clock } = state;
    uniforms.uTime.value = clock.getElapsedTime();

    const targetProgress = treeState === TreeState.FORMED ? 1.0 : 0.0;
    const material = mesh.current.material as THREE.ShaderMaterial;
    material.uniforms.uProgress.value = THREE.MathUtils.lerp(
      material.uniforms.uProgress.value,
      targetProgress,
      0.05
    );
  });

  const vertexShader = `
    uniform float uTime;
    uniform float uProgress;
    attribute vec3 chaosPos;
    attribute vec3 targetPos;
    varying vec2 vUv;
    varying float vBlink;

    void main() {
      vUv = uv;
      vec3 pos = mix(chaosPos, targetPos, uProgress);
      float noise = sin(pos.y * 2.0 + uTime) * 0.1;
      pos.x += noise * (1.0 - uProgress); 
      vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
      gl_Position = projectionMatrix * mvPosition;
      gl_PointSize = (40.0 * (1.0 + sin(uTime * 2.0 + pos.y) * 0.3)) / -mvPosition.z;
      vBlink = sin(uTime * 3.0 + pos.x);
    }
  `;

  const fragmentShader = `
    uniform vec3 uColor1;
    uniform vec3 uColor2;
    varying float vBlink;

    void main() {
      vec2 coord = gl_PointCoord - vec2(0.5);
      if(length(coord) > 0.5) discard;
      vec3 color = mix(uColor1, uColor2, step(0.8, vBlink));
      gl_FragColor = vec4(color, 1.0);
    }
  `;

  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={positions.length / 3} array={positions} itemSize={3} />
        <bufferAttribute attach="attributes-chaosPos" count={chaosPositions.length / 3} array={chaosPositions} itemSize={3} />
        <bufferAttribute attach="attributes-targetPos" count={targetPositions.length / 3} array={targetPositions} itemSize={3} />
      </bufferGeometry>
      {/* @ts-ignore */}
      <shaderMaterial
        transparent
        depthWrite={false}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
});

export default Foliage;