import React, { Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Stars, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import * as THREE from 'three';
import Foliage from './Foliage';
import Ornaments from './Ornaments';
import Polaroids from './Polaroids';
import { TreeState } from '../types';

interface SceneProps {
  treeState: TreeState;
  onPhotoClick: (id: number) => void;
  customTextureUrls?: string[];
}

const MovingCamera: React.FC = () => {
    useFrame((state) => {
        // Parallax effect based on Mouse Pointer
        // state.pointer.x is normalized -1 to 1
        const targetX = state.pointer.x * 5;
        const targetY = 4 + (state.pointer.y * 2);
        
        state.camera.position.x = THREE.MathUtils.lerp(state.camera.position.x, targetX, 0.05);
        state.camera.position.y = THREE.MathUtils.lerp(state.camera.position.y, targetY, 0.05);
        state.camera.lookAt(0, 3, 0);
    });
    return null;
};

const Scene: React.FC<SceneProps> = ({ treeState, onPhotoClick, customTextureUrls }) => {
  return (
    <Canvas
      camera={{ position: [0, 4, 20], fov: 45 }}
      gl={{ toneMapping: THREE.ReinhardToneMapping, toneMappingExposure: 1.5 }}
      dpr={[1, 2]}
    >
      <color attach="background" args={['#000500']} />
      
      <MovingCamera />
      
      <ambientLight intensity={0.5} color="#064e3b" />
      <pointLight position={[10, 10, 10]} intensity={2} color="#fbbf24" />
      <spotLight 
        position={[0, 20, 0]} 
        angle={0.5} 
        penumbra={1} 
        intensity={3} 
        castShadow 
        color="#fbbf24"
      />

      {/* Wrap async content in Suspense */}
      <Suspense fallback={null}>
          <Environment preset="lobby" background={false} blur={0.6} />
          <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
          
          <group position={[0, -2, 0]}>
            <Foliage count={2500} treeState={treeState} />
            <Ornaments count={450} treeState={treeState} />
            <Polaroids 
                treeState={treeState} 
                onPhotoClick={onPhotoClick} 
                customTextureUrls={customTextureUrls}
            />
            
            {/* Top Star */}
            <mesh position={[0, 12.5, 0]}>
                 <octahedronGeometry args={[1.5, 0]} />
                 <meshStandardMaterial 
                    color="#FCD34D" 
                    emissive="#FCD34D" 
                    emissiveIntensity={2} 
                    toneMapped={false}
                />
            </mesh>
            
            <Sparkles count={500} scale={20} size={4} speed={0.4} opacity={0.5} color="#FCD34D" />
          </group>
      </Suspense>

      <EffectComposer disableNormalPass>
        <Bloom 
            luminanceThreshold={0.7} 
            mipmapBlur 
            intensity={1.5} 
            radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={0.6} />
      </EffectComposer>
    </Canvas>
  );
};

export default Scene;