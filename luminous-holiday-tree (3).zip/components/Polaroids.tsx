import React, { useMemo, useRef, useState } from 'react';
import { useFrame, useLoader } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState, PhotoData } from '../types';

interface PolaroidsProps {
  treeState: TreeState;
  onPhotoClick: (id: number) => void;
  customTextureUrls?: string[];
}

const Polaroid: React.FC<{ 
    data: PhotoData, 
    treeState: TreeState, 
    onClick: () => void,
    imageUrl: string
}> = ({ data, treeState, onClick, imageUrl }) => {
    const groupRef = useRef<THREE.Group>(null);
    const [hovered, setHovered] = useState(false);

    // Note: If url changes, Suspense in parent handles the loading state
    const texture = useLoader(THREE.TextureLoader, imageUrl);
    
    useFrame((state, delta) => {
        if (!groupRef.current) return;
        
        const target = treeState === TreeState.FORMED ? data.targetPos : data.chaosPos;
        groupRef.current.position.lerp(target, delta * 1.5);
        
        if (treeState === TreeState.FORMED) {
           // Look at center but keep upright
           groupRef.current.lookAt(0, groupRef.current.position.y, 25);
           // Gentle bobbing
           groupRef.current.position.y += Math.sin(state.clock.elapsedTime + data.id) * 0.002;
        } else {
            // Spin slowly in chaos
            groupRef.current.rotation.x += delta * 0.5;
            groupRef.current.rotation.y += delta * 0.2;
        }

        const targetScale = hovered ? 1.5 : 1.0;
        groupRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), delta * 5);
    });

    return (
        <group 
            ref={groupRef} 
            onClick={(e) => { e.stopPropagation(); onClick(); }}
            onPointerOver={() => setHovered(true)}
            onPointerOut={() => setHovered(false)}
        >
            {/* White Frame */}
            <mesh position={[0, 0, -0.01]}>
                <boxGeometry args={[1.2, 1.4, 0.05]} />
                <meshStandardMaterial color="#f0f0f0" roughness={0.8} />
            </mesh>
            {/* Photo Image */}
            <mesh position={[0, 0.1, 0.02]}>
                <planeGeometry args={[1, 1]} />
                <meshBasicMaterial map={texture} side={THREE.DoubleSide} />
            </mesh>
        </group>
    );
};

const Polaroids: React.FC<PolaroidsProps> = React.memo(({ treeState, onPhotoClick, customTextureUrls = [] }) => {
  const photos = useMemo(() => {
    const items: PhotoData[] = [];
    const count = 30; // Increased count to accommodate more photos
    
    for (let i = 0; i < count; i++) { 
      const r = 15;
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      const chaosPos = new THREE.Vector3(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      // Spiral distribution for tree shape
      const h = -5 + (i / count) * 14; 
      const radius = 5.5 * (1 - (h + 6) / 22) + 1.0; 
      const angle = i * 1.1; // Golden angle approx
      const targetPos = new THREE.Vector3(
         radius * Math.cos(angle),
         h,
         radius * Math.sin(angle)
      );

      items.push({
        id: i,
        url: '', 
        chaosPos,
        targetPos,
        rotation: new THREE.Euler(0, 0, 0)
      });
    }
    return items;
  }, []);

  return (
    <>
      {photos.map((photo, index) => {
        // Determine URL: Use uploaded images cyclically if available, else random seed
        let url;
        if (customTextureUrls.length > 0) {
            url = customTextureUrls[index % customTextureUrls.length];
        } else {
            url = `https://picsum.photos/seed/${photo.id + 2024}/300/300`;
        }

        return (
          <Polaroid 
            key={photo.id} 
            data={photo} 
            treeState={treeState} 
            onClick={() => onPhotoClick(photo.id)}
            imageUrl={url}
          />
        );
      })}
    </>
  );
});

export default Polaroids;