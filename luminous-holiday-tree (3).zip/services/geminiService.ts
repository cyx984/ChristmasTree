import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateChristmasMemory = async (photoId: number, userContext?: string): Promise<string> => {
  try {
    const contextPrompt = userContext ? `The user provided this context about the photo: "${userContext}".` : "";
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are a holiday spirit filled with Christmas magic. Based on a photo hanging on a magical Christmas tree, ${contextPrompt} please generate a short, heartwarming, cinematic Christmas memory (max 2 sentences). The tone should be nostalgic and warm.`,
    });
    return response.text || "A warm glow surrounds this memory...";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "The magic of Christmas keeps this memory safe forever.";
  }
};